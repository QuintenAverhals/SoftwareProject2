
<tr>
@foreach($results->value as $value)
<td> {{$value->UserName}} </td>
@endforeach

</tr>

