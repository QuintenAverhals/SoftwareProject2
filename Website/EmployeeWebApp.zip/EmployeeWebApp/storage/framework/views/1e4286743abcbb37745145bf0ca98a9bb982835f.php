
<tr>
<?php $__currentLoopData = $results->value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<td> <?php echo e($value->UserName); ?> </td>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</tr>