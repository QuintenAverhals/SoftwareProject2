
<!DOCTYPE html>
<html>
<head>
	<title>Training Aanvraag</title>

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/docs.min')); ?>">
    <style type="text/css">
    	
    	body{
    		background: url("<?php echo e(asset('images/backgroundFoto.jpg')); ?>") no-repeat center center fixed; 
    		background-size: 100% auto;
    	}
    	header{opacity: 0.7;}
    	footer{background-color: #937f7b;opacity: 0.9;text-align: center;}
    </style>

</head>
<body>
	<header class="jumbotron">
    <div class="container">
      <h1>Nieuwe Training Aanvraag</h1>
      <p> U kunt via deze form een nieuwe aanvraag indienen </p>
    </div>

			</header>
<div class="container">
<!--form >
  <div class="form-group row">
    <label for="TraingNaam" >Training naam</label>
    <input type="text" class="form-control" id="naamTraining" placeholder="Geef Training naam">
  </div>
  <div class="form-group">
    <label for="SoortTraining">Welke Training wil je volgen:</label>
    <input type="text" class="form-control" id="Soort" placeholder="Geef soort Training">
  </div>
   <div class="form-group">
    <label for="plaatsTraining">Waar wil je volgen:</label>
    <input type="text" class="form-control" id="plaats" placeholder="plaats van Training">
  </div>
  <button type="submit" class="btn btn-primary">Stuur</button>
</form-->

  <!--Aanmaken van de nieuwe aanvraag Training -->

  <?php echo Form::open(["url"=>"training","files"=>"true"]); ?>

  TrainingNaam :<?php echo Form::text("training_name"); ?> <br/> 
  Start-date :<?php echo Form::text("start_date"); ?> <br/> 
  Eind-date :<?php echo Form::text("eind_date"); ?> <br/> 
  Start-time :<?php echo Form::text("start_time"); ?> <br/> 
  eind-time :<?php echo Form::text("end_time"); ?> <br/> 
  location :<?php echo Form::text("location"); ?> <br/> 
  Survy :<?php echo Form::text("survy_id"); ?> <br/> 
  Status :<?php echo Form::text("status"); ?> <br/> 
  visibility :<?php echo Form::text("visibility"); ?> <br/> 





  <?php echo Form::submit("Stuur Aanvraag",["class"=>"btn btn-info"]); ?>

   


  <?php echo Form::close(); ?>




   </div>



	<footer class="container">
   
&copy;Groep 7

  </footer>

</body>
</html>